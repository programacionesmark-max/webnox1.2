'use client'

import Link from 'next/link'

export function Footer() {
  const currentYear = new Date().getFullYear()

  return (
    <footer className="relative py-16 border-t border-white/5">
      <div className="max-w-6xl mx-auto px-6 sm:px-12 lg:px-24">
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-10 mb-16">
          {/* Brand */}
          <div className="lg:col-span-2">
            <Link href="/" className="text-lg tracking-wider font-light">WEBNOX</Link>
            <p className="mt-4 text-sm text-white/30 max-w-xs leading-relaxed">
              Precision digital engineering. No templates, no compromises.
            </p>
            <div className="flex items-center gap-2 mt-6">
              <span className="w-1.5 h-1.5 bg-green-400 rounded-full" />
              <span className="text-xs text-white/20">Available for projects</span>
            </div>
          </div>

          {/* Links */}
          <div>
            <h4 className="text-xs tracking-[0.15em] text-white/20 uppercase mb-4">Navigation</h4>
            <ul className="space-y-3">
              {[
                { name: 'Projects', href: '/projects' },
                { name: 'Stack', href: '/stack' },
                { name: 'Plans', href: '/plans' },
                { name: 'Contact', href: '/contact' },
              ].map((link) => (
                <li key={link.name}>
                  <Link href={link.href} className="text-sm text-white/40 hover:text-white/70 transition-colors">
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Legal */}
          <div>
            <h4 className="text-xs tracking-[0.15em] text-white/20 uppercase mb-4">Legal</h4>
            <ul className="space-y-3">
              {['Privacy', 'Terms'].map((link) => (
                <li key={link}>
                  <Link href="#" className="text-sm text-white/40 hover:text-white/70 transition-colors">
                    {link}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Bottom */}
        <div className="flex flex-col sm:flex-row justify-between items-center gap-4 pt-8 border-t border-white/5">
          <span className="text-xs text-white/20">© {currentYear} WEBNOX</span>
          <span className="text-xs text-white/20">Sint Willebrord, NL</span>
        </div>
      </div>
    </footer>
  )
}
