'use client'

import { motion } from 'framer-motion'
import { ArrowLeft, Cpu, Database, Globe, Lock, Rocket, Code2, Check, Zap, Shield, Gauge, Sparkles, GitBranch, Cloud, Smartphone, Palette, Search, Monitor, Users, Clock, FileCode, Layers } from 'lucide-react'
import Link from 'next/link'
import { Navbar } from '@/components/layout/Navbar'
import { Footer } from '@/components/layout/Footer'
import { 
  GalacticBackground, 
  ParticleConnections, 
  CustomCursor, 
  GrainOverlay,
  ScrollProgress,
  OrbitingElements
} from '@/components/layout/PageEffects'

const easeLux = [0.16, 1, 0.3, 1] as const

const technologies = [
  { icon: Cpu, title: 'Frontend', desc: 'Next.js 14, React, TypeScript. Server components, static generation, 60fps interactions.', tech: ['Next.js', 'React', 'TypeScript', 'Tailwind'] },
  { icon: Database, title: 'Backend & Data', desc: 'Sanity CMS for content, Supabase for dynamic data and authentication.', tech: ['Sanity', 'Supabase', 'PostgreSQL'] },
  { icon: Globe, title: 'Infrastructure', desc: 'Vercel Edge Network: 18 global regions, instant invalidation, 100% uptime.', tech: ['Vercel', 'Edge Functions', 'CDN'] },
  { icon: Lock, title: 'Security', desc: 'Automatic HTTPS, CSP headers, XSS protection, automatic updates.', tech: ['HTTPS', 'CSP', 'DDoS Protection'] },
  { icon: Rocket, title: 'Performance', desc: 'Guaranteed LCP < 100ms, Lighthouse 100/100, lazy loading, code splitting.', tech: ['Image Optim', 'Lazy Load', 'Code Split'] },
  { icon: Code2, title: 'Dev Experience', desc: 'Strict TypeScript, ESLint, Prettier, Storybook, CI/CD with GitHub Actions.', tech: ['TypeScript', 'ESLint', 'GitHub Actions'] },
]

const processSteps = [
  { step: '01', title: 'Discovery', desc: '30 min call to understand goals, audience and requirements.', time: '1 day' },
  { step: '02', title: 'Proposal', desc: 'Document with scope, timeline, price and proposed technologies.', time: '1-2 days' },
  { step: '03', title: 'Design', desc: 'Wireframes and visual design. Iterations until final approval.', time: '1-2 weeks' },
  { step: '04', title: 'Development', desc: 'Building with weekly demos. Continuous feedback.', time: '1-3 weeks' },
  { step: '05', title: 'QA & Launch', desc: 'Exhaustive testing, migration, analytics configuration.', time: '2-3 days' },
  { step: '06', title: 'Support', desc: 'Post-launch support and issue resolution.', time: '14-60 days' },
]

const guarantees = [
  { icon: Gauge, title: 'Lighthouse 100/100', desc: 'Perfect score guaranteed' },
  { icon: Zap, title: 'LCP < 100ms', desc: 'Ultra-fast loading' },
  { icon: Shield, title: '100% own code', desc: 'No lock-in, no licenses' },
  { icon: Clock, title: 'Support included', desc: '14-60 days depending on plan' },
]

const integrations = [
  { icon: GitBranch, name: 'GitHub', desc: 'Version control' },
  { icon: Cloud, name: 'Vercel', desc: 'Hosting & edge' },
  { icon: Smartphone, name: 'PWA Ready', desc: 'Mobile installable' },
  { icon: Palette, name: 'Figma', desc: 'Collaborative design' },
  { icon: Search, name: 'Analytics', desc: 'Vercel + GA4' },
  { icon: Monitor, name: 'Monitoring', desc: 'Error tracking 24/7' },
  { icon: Users, name: 'CRM', desc: 'HubSpot, Salesforce' },
  { icon: FileCode, name: 'APIs', desc: 'REST & GraphQL' },
]

const techStack = [
  { category: 'Frontend', items: ['Next.js 14', 'React 18', 'TypeScript', 'Tailwind CSS', 'Framer Motion', 'GSAP'] },
  { category: 'Backend', items: ['Node.js', 'Supabase', 'PostgreSQL', 'Sanity CMS', 'Stripe API', 'SendGrid'] },
  { category: 'DevOps', items: ['Vercel', 'GitHub Actions', 'Cloudflare', 'Sentry', 'Lighthouse CI'] },
  { category: 'Tools', items: ['Figma', 'VS Code', 'Cursor', 'Notion', 'Slack'] },
]

export default function StackPage() {
  return (
    <main className="relative min-h-screen bg-[#050505] text-white overflow-x-hidden">
      <GalacticBackground />
      <ParticleConnections />
      <OrbitingElements />
      <GrainOverlay />
      <ScrollProgress />
      <CustomCursor />
      <Navbar />

      <div className="relative z-10 pt-32 pb-20">
        <div className="max-w-6xl mx-auto px-6 sm:px-12 lg:px-24">
          {/* Header */}
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="mb-16"
          >
            <Link
              href="/"
              className="inline-flex items-center gap-2 text-white/30 hover:text-white transition-colors mb-8 text-sm"
            >
              <ArrowLeft size={14} />
              Home
            </Link>
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-light mb-4">Technology Stack</h1>
            <p className="text-white/30 max-w-lg">
              We use the most modern technologies to create ultra-fast, secure, and scalable sites.
            </p>
          </motion.div>

          {/* Technologies Grid */}
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-20">
            {technologies.map((tech, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                className="p-6 border border-white/5 hover:border-white/10 transition-colors"
              >
                <tech.icon className="w-5 h-5 mb-4 text-white/40" />
                <h3 className="text-lg font-light mb-2">{tech.title}</h3>
                <p className="text-sm text-white/30 mb-4">{tech.desc}</p>
                <div className="flex flex-wrap gap-2">
                  {tech.tech.map((t, j) => (
                    <span key={j} className="px-2 py-1 text-xs bg-white/5 text-white/40">{t}</span>
                  ))}
                </div>
              </motion.div>
            ))}
          </div>

          {/* Process */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="py-16 border-t border-white/5 mb-16"
          >
            <h2 className="text-2xl font-light mb-12 text-center">Work process</h2>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
              {processSteps.map((step, i) => (
                <div key={i}>
                  <div className="text-3xl font-light text-white/10 mb-4">{step.step}</div>
                  <h3 className="text-sm mb-2">{step.title}</h3>
                  <p className="text-xs text-white/30 mb-2">{step.desc}</p>
                  <span className="text-xs text-white/20">{step.time}</span>
                </div>
              ))}
            </div>
          </motion.div>

          {/* Tech Stack Detail */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="py-16 border-t border-white/5 mb-16"
          >
            <h2 className="text-2xl font-light mb-10">Technologies we use</h2>
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
              {techStack.map((cat, i) => (
                <div key={i}>
                  <h3 className="text-xs tracking-[0.15em] text-white/20 uppercase mb-4">{cat.category}</h3>
                  <ul className="space-y-2">
                    {cat.items.map((item, j) => (
                      <li key={j} className="text-sm text-white/50">{item}</li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </motion.div>

          {/* Integrations */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="py-16 border-t border-white/5 mb-16"
          >
            <h2 className="text-2xl font-light mb-10 text-center">Integrations</h2>
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {integrations.map((int, i) => (
                <div key={i} className="flex items-center gap-3 p-4 border border-white/5">
                  <int.icon className="w-4 h-4 text-white/40" />
                  <div>
                    <h4 className="text-sm">{int.name}</h4>
                    <p className="text-xs text-white/30">{int.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>

          {/* Guarantees */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="py-12 border border-white/5 mb-16"
          >
            <h2 className="text-2xl font-light mb-10 text-center">Guarantees</h2>
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
              {guarantees.map((item, i) => (
                <div key={i} className="text-center">
                  <item.icon className="w-6 h-6 mx-auto mb-3 text-white/40" />
                  <h4 className="text-sm mb-1">{item.title}</h4>
                  <p className="text-xs text-white/30">{item.desc}</p>
                </div>
              ))}
            </div>
          </motion.div>

          {/* CTA */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center py-12 border-t border-white/5"
          >
            <p className="text-white/30 mb-6 text-sm">Want to know more?</p>
            <Link
              href="/contact"
              className="inline-flex items-center gap-2 px-8 py-4 border border-white/10 text-sm tracking-wider uppercase hover:bg-white hover:text-black transition-all"
            >
              Let's talk
            </Link>
          </motion.div>
        </div>
      </div>

      <Footer />
    </main>
  )
}
