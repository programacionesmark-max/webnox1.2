'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'
import { ArrowLeft, Check, HelpCircle, Calculator, ArrowRight, Clock, Zap, Shield, Globe, HeadphonesIcon, Code2, Palette, TrendingUp } from 'lucide-react'
import Link from 'next/link'
import { Navbar } from '@/components/layout/Navbar'
import { Footer } from '@/components/layout/Footer'
import { 
  GalacticBackground, 
  ParticleConnections, 
  CustomCursor, 
  GrainOverlay,
  ScrollProgress,
  OrbitingElements
} from '@/components/layout/PageEffects'

const easeLux = [0.16, 1, 0.3, 1] as const

const oneTimePlans = [
  {
    name: 'STARTER',
    price: '€790',
    desc: 'Professional landing page for startups and entrepreneurs.',
    duration: '5-7 days',
    features: [
      'Unique custom design',
      '100% mobile responsive',
      'Contact form',
      'WhatsApp integration',
      'Basic SEO included',
      'Free 1 year hosting',
      '14 days support',
      '2 revisions included',
    ],
    bestFor: 'Startups, product landing, launch pages',
    highlight: false
  },
  {
    name: 'BUSINESS',
    price: '€1,490',
    desc: 'Complete corporate website with CMS to edit content.',
    duration: '2-3 weeks',
    features: [
      'Up to 6 custom pages',
      'CMS included (Sanity)',
      'Blog / news integrated',
      'Elegant animations',
      'Advanced technical SEO',
      'Google Analytics configured',
      'Social media integration',
      'Free 1 year hosting',
      '30 days support',
      '4 revisions included',
    ],
    bestFor: 'SMBs, consultancies, agencies, freelancers',
    highlight: true
  },
  {
    name: 'PREMIUM',
    price: '€2,290',
    desc: 'Premium website with all advanced features.',
    duration: '3-4 weeks',
    features: [
      'Up to 10 custom pages',
      'Advanced CMS (Sanity Pro)',
      'Blog + portfolio integrated',
      'Premium animations',
      'Complete technical SEO',
      'Multi-language ready',
      'Reservation system',
      'Transactional emails',
      'Free 1 year hosting',
      '60 days support',
      'Unlimited revisions',
    ],
    bestFor: 'Established companies, small e-commerce, restaurants, hotels',
    highlight: false
  },
]

const addOns = [
  { name: 'Additional page', price: '+€150', desc: 'Each extra page you need' },
  { name: 'Multi-language', price: '+€390', desc: 'Preparation for 2+ languages' },
  { name: 'Basic e-commerce', price: '+€590', desc: 'Store with up to 20 products' },
  { name: 'Reservation system', price: '+€290', desc: 'Calendar + appointment management' },
  { name: 'Advanced SEO', price: '+€190', desc: 'Audit + optimization + schema' },
  { name: 'Complete branding', price: '+€490', desc: 'Logo + palette + typography' },
]

const subscriptionPlans = [
  {
    name: 'CARE',
    price: '€99',
    period: '/month',
    desc: 'Essential maintenance for your website.',
    features: [
      'Security updates',
      'Automatic weekly backups',
      '24/7 uptime monitoring',
      '1 hour of changes/month',
      'Email support',
    ],
    bestFor: 'Sites that need basic maintenance',
  },
  {
    name: 'GROWTH',
    price: '€249',
    period: '/month',
    desc: 'Active support and continuous improvements.',
    features: [
      'Everything in Care',
      '3 hours of development/month',
      'Unlimited content changes',
      'Performance optimization',
      'Priority support',
      'Monthly report',
    ],
    bestFor: 'Companies in active growth',
    highlight: true
  },
  {
    name: 'PARTNER',
    price: '€499',
    period: '/month',
    desc: 'Your dedicated development team.',
    features: [
      'Everything in Growth',
      '8 hours of development/month',
      'New features',
      'Additional landing pages',
      'Dedicated Slack support',
      'Monthly strategy meeting',
    ],
    bestFor: 'Companies with continuous needs',
  },
]

const processSteps = [
  { step: '01', title: 'Consultation', desc: '30 min call to understand your project and goals.', time: '1 day' },
  { step: '02', title: 'Proposal', desc: 'Detailed document with scope, price and timeline.', time: '1-2 days' },
  { step: '03', title: 'Design', desc: 'Wireframes + visual design. We iterate until you\'re satisfied.', time: '1-2 weeks' },
  { step: '04', title: 'Development', desc: 'Building with weekly demos for feedback.', time: '1-3 weeks' },
  { step: '05', title: 'Launch', desc: 'Testing, migration and team training.', time: '2-3 days' },
]

const faqs = [
  { q: 'What does the price include?', a: 'Design, development, hosting configuration, technical SEO and post-launch support. No hidden costs.' },
  { q: 'How does payment work?', a: '50% to start, 50% on delivery. We accept bank transfer and card. For subscriptions, monthly payment.' },
  { q: 'Do I own the source code?', a: 'Yes, 100%. Upon completion we transfer the complete repository to your GitHub. No lock-in.' },
  { q: 'Can I edit the content?', a: 'Yes, from the Business plan we include CMS (Sanity) to edit texts and images without knowing how to code.' },
  { q: 'What if I need changes?', a: 'We include free support (14-60 days depending on plan). After that you can hire maintenance or pay by hours.' },
  { q: 'How long does it take?', a: 'Starter: 5-7 days. Business: 2-3 weeks. Premium: 3-4 weeks. Depends on complexity and your feedback.' },
  { q: 'Do you offer hosting?', a: 'We configure hosting on Vercel (recommended). First year free, then you pay directly (from free).' },
  { q: 'Do you work with companies outside Europe?', a: 'Yes, we work with clients from all over Europe and Latin America. Communication via video and Slack.' },
]

export default function PlansPage() {
  const [activeTab, setActiveTab] = useState<'one-time' | 'subscription'>('one-time')
  const [traffic, setTraffic] = useState(5000)
  const [conversion, setConversion] = useState(2)
  const [aov, setAov] = useState(50)

  const currentRevenue = traffic * (conversion / 100) * aov
  const projectedRevenue = currentRevenue * 1.25
  const roi = projectedRevenue - currentRevenue

  return (
    <main className="relative min-h-screen bg-[#050505] text-white overflow-x-hidden">
      <GalacticBackground />
      <ParticleConnections />
      <OrbitingElements />
      <GrainOverlay />
      <ScrollProgress />
      <CustomCursor />
      <Navbar />

      <div className="relative z-10 pt-32 pb-20">
        <div className="max-w-6xl mx-auto px-6 sm:px-12 lg:px-24">
          {/* Header */}
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: easeLux }}
            className="text-center mb-16"
          >
            <Link
              href="/"
              className="inline-flex items-center gap-2 text-white/30 hover:text-white transition-colors mb-8 text-sm"
            >
              <ArrowLeft size={14} />
              Home
            </Link>
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-light mb-4">Investment</h1>
            <p className="text-white/30 max-w-lg mx-auto">
              Transparent pricing. No surprises. Each plan designed to maximize your return.
            </p>
          </motion.div>

          {/* Tabs */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="flex justify-center gap-4 mb-16"
          >
            <button
              onClick={() => setActiveTab('one-time')}
              className={`px-6 py-3 text-sm tracking-wider uppercase transition-all ${
                activeTab === 'one-time'
                  ? 'bg-white text-black'
                  : 'border border-white/10 text-white/40 hover:border-white/30'
              }`}
            >
              Projects
            </button>
            <button
              onClick={() => setActiveTab('subscription')}
              className={`px-6 py-3 text-sm tracking-wider uppercase transition-all ${
                activeTab === 'subscription'
                  ? 'bg-white text-black'
                  : 'border border-white/10 text-white/40 hover:border-white/30'
              }`}
            >
              Subscriptions
            </button>
          </motion.div>

          {/* Plans */}
          {activeTab === 'one-time' ? (
            <>
              <div className="grid md:grid-cols-3 gap-6 mb-16">
                {oneTimePlans.map((plan, i) => (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0, y: 30 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.1 }}
                    className={`relative p-8 ${
                      plan.highlight 
                        ? 'border border-white/20 bg-white/[0.02]' 
                        : 'border border-white/5'
                    }`}
                  >
                    {plan.highlight && (
                      <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-4 py-1 bg-white text-black text-xs tracking-wider uppercase">
                        Popular
                      </div>
                    )}
                    <span className="text-xs tracking-[0.15em] text-white/30 uppercase">{plan.name}</span>
                    <div className="text-4xl font-light mt-4 mb-2">{plan.price}</div>
                    <p className="text-sm text-white/40 mb-4">{plan.desc}</p>
                    <div className="text-xs text-white/20 mb-6 flex items-center gap-2">
                      <Clock size={12} />
                      {plan.duration}
                    </div>
                    
                    <ul className="space-y-2 mb-8">
                      {plan.features.map((f, j) => (
                        <li key={j} className="flex items-start gap-2 text-sm text-white/50">
                          <Check size={12} className="text-white/30 mt-0.5 shrink-0" />
                          {f}
                        </li>
                      ))}
                    </ul>
                    
                    <div className="text-xs text-white/20 mb-6 pt-4 border-t border-white/5">
                      <strong className="text-white/40">Best for:</strong> {plan.bestFor}
                    </div>
                    
                    <Link
                      href="/contact"
                      className={`block w-full py-3 text-center text-sm tracking-wider uppercase transition-all ${
                        plan.highlight
                          ? 'bg-white text-black hover:bg-white/90'
                          : 'border border-white/10 hover:border-white/30'
                      }`}
                    >
                      Request
                    </Link>
                  </motion.div>
                ))}
              </div>

              {/* Add-ons */}
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="mb-20"
              >
                <h2 className="text-2xl font-light mb-8">Add-ons</h2>
                <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  {addOns.map((addon, i) => (
                    <div key={i} className="flex justify-between items-start p-5 border border-white/5 hover:border-white/10 transition-colors">
                      <div>
                        <h3 className="text-sm mb-1">{addon.name}</h3>
                        <p className="text-xs text-white/30">{addon.desc}</p>
                      </div>
                      <span className="text-sm text-white/50">{addon.price}</span>
                    </div>
                  ))}
                </div>
              </motion.div>
            </>
          ) : (
            <div className="grid md:grid-cols-3 gap-6 mb-16">
              {subscriptionPlans.map((plan, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.1 }}
                  className={`relative p-8 ${
                    plan.highlight 
                      ? 'border border-white/20 bg-white/[0.02]' 
                      : 'border border-white/5'
                  }`}
                >
                  {plan.highlight && (
                    <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-4 py-1 bg-white text-black text-xs tracking-wider uppercase">
                      Recommended
                    </div>
                  )}
                  <span className="text-xs tracking-[0.15em] text-white/30 uppercase">{plan.name}</span>
                  <div className="text-4xl font-light mt-4 mb-2">
                    {plan.price}
                    <span className="text-lg text-white/30">{plan.period}</span>
                  </div>
                  <p className="text-sm text-white/40 mb-6">{plan.desc}</p>
                  
                  <ul className="space-y-2 mb-8">
                    {plan.features.map((f, j) => (
                      <li key={j} className="flex items-start gap-2 text-sm text-white/50">
                        <Check size={12} className="text-white/30 mt-0.5 shrink-0" />
                        {f}
                      </li>
                    ))}
                  </ul>
                  
                  <div className="text-xs text-white/20 mb-6 pt-4 border-t border-white/5">
                    <strong className="text-white/40">Best for:</strong> {plan.bestFor}
                  </div>
                  
                  <Link
                    href="/contact"
                    className={`block w-full py-3 text-center text-sm tracking-wider uppercase transition-all ${
                      plan.highlight
                        ? 'bg-white text-black hover:bg-white/90'
                        : 'border border-white/10 hover:border-white/30'
                    }`}
                  >
                    Start
                  </Link>
                </motion.div>
              ))}
            </div>
          )}

          {/* Process */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="mb-20 py-16 border-t border-white/5"
          >
            <h2 className="text-2xl font-light mb-12 text-center">Work process</h2>
            <div className="grid sm:grid-cols-3 lg:grid-cols-5 gap-8">
              {processSteps.map((step, i) => (
                <div key={i} className="text-center">
                  <div className="text-4xl font-light text-white/10 mb-4">{step.step}</div>
                  <h3 className="text-sm mb-2">{step.title}</h3>
                  <p className="text-xs text-white/30 mb-2">{step.desc}</p>
                  <span className="text-xs text-white/20">{step.time}</span>
                </div>
              ))}
            </div>
          </motion.div>

          {/* ROI Calculator */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="mb-20 py-12 border border-white/5"
          >
            <div className="text-center mb-10">
              <Calculator className="w-6 h-6 mx-auto mb-4 text-white/30" />
              <h2 className="text-2xl font-light">ROI Calculator</h2>
              <p className="text-sm text-white/30 mt-2">Estimate your investment return</p>
            </div>

            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8 px-4 sm:px-8">
              <div>
                <label className="text-xs text-white/30 block mb-3">Visitors/month</label>
                <input
                  type="range"
                  min="500"
                  max="50000"
                  step="500"
                  value={traffic}
                  onChange={(e) => setTraffic(Number(e.target.value))}
                  className="w-full accent-white/50"
                />
                <div className="text-lg mt-2">{traffic.toLocaleString()}</div>
              </div>
              <div>
                <label className="text-xs text-white/30 block mb-3">Conversion (%)</label>
                <input
                  type="range"
                  min="0.5"
                  max="8"
                  step="0.1"
                  value={conversion}
                  onChange={(e) => setConversion(Number(e.target.value))}
                  className="w-full accent-white/50"
                />
                <div className="text-lg mt-2">{conversion}%</div>
              </div>
              <div>
                <label className="text-xs text-white/30 block mb-3">Average order (€)</label>
                <input
                  type="range"
                  min="10"
                  max="300"
                  step="5"
                  value={aov}
                  onChange={(e) => setAov(Number(e.target.value))}
                  className="w-full accent-white/50"
                />
                <div className="text-lg mt-2">{aov}€</div>
              </div>
              <div>
                <label className="text-xs text-white/30 block mb-3">Extra revenue/month</label>
                <div className="text-3xl font-light">+{roi.toFixed(0)}€</div>
                <div className="text-xs text-white/20 mt-1">with 25% improvement</div>
              </div>
            </div>
          </motion.div>

          {/* What's included */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="mb-20 py-12 border-t border-white/5"
          >
            <h2 className="text-2xl font-light mb-10 text-center">What each project includes</h2>
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
              {[
                { icon: Code2, title: 'Own code', desc: '100% of code is yours, no licenses' },
                { icon: Palette, title: 'Unique design', desc: 'No templates, each design is exclusive' },
                { icon: Shield, title: 'Security', desc: 'HTTPS, CSP headers, XSS protection' },
                { icon: Globe, title: 'Free hosting', desc: 'First year included in all plans' },
                { icon: Zap, title: 'Performance', desc: 'Optimized for Lighthouse 100/100' },
                { icon: TrendingUp, title: 'Technical SEO', desc: 'Schema, meta tags, XML sitemap' },
                { icon: HeadphonesIcon, title: 'Support', desc: '14-60 days depending on plan' },
                { icon: Clock, title: 'Fast delivery', desc: 'From 5 days for simple projects' },
              ].map((item, i) => (
                <div key={i} className="text-center sm:text-left">
                  <item.icon className="w-5 h-5 mb-3 text-white/40" />
                  <h3 className="text-sm mb-1">{item.title}</h3>
                  <p className="text-xs text-white/30">{item.desc}</p>
                </div>
              ))}
            </div>
          </motion.div>

          {/* FAQs */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <div className="text-center mb-10">
              <HelpCircle className="w-6 h-6 mx-auto mb-4 text-white/30" />
              <h2 className="text-2xl font-light">Frequently asked questions</h2>
            </div>

            <div className="max-w-2xl mx-auto">
              {faqs.map((faq, i) => (
                <details key={i} className="group border-b border-white/5">
                  <summary className="flex justify-between items-center py-5 cursor-pointer list-none">
                    <span className="text-sm font-light pr-4">{faq.q}</span>
                    <span className="text-white/20 group-open:rotate-45 transition-transform text-xl">+</span>
                  </summary>
                  <div className="pb-5 text-sm text-white/40">{faq.a}</div>
                </details>
              ))}
            </div>
          </motion.div>

          {/* CTA */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="mt-20 text-center"
          >
            <p className="text-white/30 mb-6 text-sm">Can't find what you need?</p>
            <Link
              href="/contact"
              className="inline-flex items-center gap-2 px-8 py-4 border border-white/10 text-sm tracking-wider uppercase hover:bg-white hover:text-black transition-all"
            >
              Get custom quote
              <ArrowRight size={14} />
            </Link>
          </motion.div>
        </div>
      </div>

      <Footer />
    </main>
  )
}
